const mongoose = require('mongoose');
const {Schema, model} = require("mongoose");
const {Page, Field} = require("../models/formmodule-model");

const multer = require('multer');
const path = require('path');


const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

// Multer middleware for single image file upload
const upload = multer({
    storage: storage,
    limits: { fileSize: 1000000 }, // Limit the file size (optional)
}).single('image'); // 'image' is the name of the field in the form


const add = async (req,res)=>{
    try {
        const { user_id, page_name} = req.body;

      
        const pageExist = await Page.findOne({ page_name:page_name ,user_id:user_id });
      
        if(!pageExist){
            res.status(500).json({ error:"Code Error", details:"Page name doesn't exist"});
        }

        const table_name = pageExist.table_name;
        const page_id= pageExist.id;

        const fields = await Field.find({page_id:page_id});
        
        let schemaFields = {};
        //model 
        for (const field of fields) {

            const name = field.fields_name ;
            const type = field.type; 
           
            // Dynamically add each field to the schema
            schemaFields[name] = { type: type };


            // Validation check
            if (field.fields_validation === "yes") {
                if (!req.body.fields || !req.body.fields[name]) {
                    return res.status(400).json({
                        error: "Validation Error",
                        details: `Field '${name}' is required`,
                    });
                }
            }
        }

        // Adding fixed fields to the schema
        schemaFields["user_id"] = { type: String };
        schemaFields["createdDate"] = { type: Date };
        
       // Check if the model already exists to avoid redefining it
        let DB;
        if (mongoose.models[table_name]) {
            DB = mongoose.models[table_name];
        } else {
            // Create the model if it doesn't already exist
            const dynamicSchema = new mongoose.Schema(schemaFields, { collection: table_name }); // Specify the collection name
            DB = mongoose.model(table_name, dynamicSchema);
        }

      
        // Save the document into the collection
        const savedField = await DB.create({
            user_id: req.body.user_id,
            createdDate: new Date(),
            ...req.body.fields // Assuming fields contain other dynamic data
        });

        console.log("Saved document:", savedField);
        
        res.status(201).json({
            msg:"form submitted ", 
        });
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
    }catch(error){
        console.error("Error in add:", error.message); // Log the error message
        res.status(500).json({ error: "Internal Server Error", details: error.message }); // Send the error message in the response
    }
    
}

module.exports = {add};
