const Pri = require("../models/privilege-model");
const User = require("../models/user-model");
const bcrypt = require("bcryptjs");

const addrole = async (req,res)=>{
    try {
 
        const { role, createdby } = req.body;

        const userExist = await Pri.findOne({ role });
        
        if(userExist){
            return res.status(400).json({msg:"Role already exist"});

        }
        const cmCreated =  await Pri.create( { role, createdby} );
        res.status(201).json({
            msg:cmCreated,
             userId:cmCreated._id.toString(),
        });

    } catch (error) {
        console.error("Error in addrole:", error.message); // Log the error message
        res.status(500).json({ error: "Internal Server Error", details: error.message }); // Send the error message in the response
    }
};

const editrole = async (req,res)=>{
    try {
 
        const { role } = req.body;
        const id = req.params.id;
        const userExist = await Pri.findOne({ role, _id: { $ne: id } });
        
        if(userExist){
            return res.status(400).json({msg:"Role already exist"});

        }
        const cmCreated =  await Pri.create( { role} );
        res.status(201).json({
            msg:cmCreated,
             userId:cmCreated._id.toString(),
        });

    } catch (error) {
        console.error("Error in editrole:", error.message); // Log the error message
        res.status(500).json({ error: "Internal Server Error", details: error.message }); // Send the error message in the response
    }
};



const  getrolebyid = async(req, res) => {
    try {
        const id = req.params.id;
        const response = await await Pri.findOne({ _id: id });
        if(!response){
            res.status(404).json({msg:"No Data Found"});
            return;
        }
        res.status(200).json({msg:response});
    } catch (error) {
        console.error("Error in getrolebyid:", error.message); // Log the error message
        res.status(500).json({ error: "Internal Server Error", details: error.message }); // Send the error message in the response
    }
};

const  deleterole = async(req, res) => {
    try {
        const id = req.params.id;
        const response = await Pri.findOneAndDelete(({_id:id}));
        const response2 = await User.findOneAndDelete(({role:id}));
        if(!response){
            res.status(404).json({msg:"No Data Found"});
            return;
        }
        res.status(200).json({msg:response});
    } catch (error) {
        console.error("Error in deleterole:", error.message); // Log the error message
        res.status(500).json({ error: "Internal Server Error", details: error.message }); // Send the error message in the response
    }
};

const  getroles = async(req, res) => {
    try {
        const response = await Pri.find();
        if(!response){
            res.status(404).json({msg:"No Data Found"});
            return;
        }
        res.status(200).json({msg:response});
    } catch (error) {
        console.error("Error in getroles:", error.message); // Log the error message
        res.status(500).json({ error: "Internal Server Error", details: error.message }); // Send the error message in the response
    }
};

//add user as per roles
const adduser = async (req,res)=>{
    try {
        console.log(req.body);
        const { username, email, phone, password, role } = req.body;
        const status= '1';    
        
        const userExist = await User.findOne({ email });
        
        if(userExist){
            return res.status(400).json({msg:"Email ID already exist"});

        }
        const cmCreated =  await User.create( { username, email, phone, password, status,role} );
        res.status(201).json({
            msg:cmCreated,
            userId:cmCreated._id.toString(),
        });

    } catch (error) {
        console.error("Error in adduser:", error.message); // Log the error message
        res.status(500).json({ error: "Internal Server Error", details: error.message }); // Send the error message in the response
    }
};

const updateuser = async (req,res)=>{
    try {
        console.log(req.body);
        const { username, email, phone, password, role } = req.body;
 
        const saltRound = await bcrypt.genSalt(10);
        const hash_password = await bcrypt.hash(password, saltRound);
        const id = req.params.id;
 
        const userExist = await User.findOne({ email, _id: { $ne: id }});
        
        if(userExist){
            return res.status(400).json({msg:"User already exist"});

        }
        const result = await User.updateOne({ _id:id },{
            $set:{
                username: username,
                email: email,   
                phone: phone,   
                password: hash_password, 
                role:role,  
            }
        },{
            new:true,
        });
        res.status(201).json({
            msg:'Updated Successfully',
        });

    } catch (error) {
        console.error("Error in updateuser:", error.message); // Log the error message
        res.status(500).json({ error: "Internal Server Error", details: error.message }); // Send the error message in the response
    }
};

const  getuser = async(req, res) => {
    try {
        const response = await User.find({ isAdmin: { $ne: 'true' } });
        if(!response){
            res.status(404).json({msg:"No Data Found"});
            return;
        }
        res.status(200).json({msg:response});
    } catch (error) {
        console.error("Error in getuser:", error.message); // Log the error message
        res.status(500).json({ error: "Internal Server Error", details: error.message }); // Send the error message in the response
    }
};

const  getuserbyid = async(req, res) => {
    try {
        const id = req.params.id;
        const response = await await User.findOne({ _id: id });
        if(!response){
            res.status(404).json({msg:"No Data Found"});
            return;
        }
        res.status(200).json({msg:response});
    } catch (error) {
        console.error("Error in getuserbyid:", error.message); // Log the error message
        res.status(500).json({ error: "Internal Server Error", details: error.message }); // Send the error message in the response
    }
};

const  deleteuser = async(req, res) => {
    try {

        const id = req.params.id;
        const response = await User.findOneAndDelete(({_id:id}));
        if(!response){
            res.status(404).json({msg:"No Data Found"});
            return;
        }
        res.status(200).json({msg:response});
    } catch (error) {
        console.error("Error in deleteuser:", error.message); // Log the error message
        res.status(500).json({ error: "Internal Server Error", details: error.message }); // Send the error message in the response
    }
};

const statususer = async (req,res)=>{
    try {
        
        const { status } = req.body;
        const id = req.params.id;
    
        const result = await User.updateOne({ _id:id },{
            $set:{
                status: status,
            }
        },{
            new:true,
        });
        res.status(201).json({
            msg:'Updated Successfully',
        });

    } catch (error) {
        console.error("Error in statususer:", error.message); // Log the error message
        res.status(500).json({ error: "Internal Server Error", details: error.message }); // Send the error message in the response
    }
};

module.exports = { addrole , editrole , getrolebyid, deleterole , getroles, adduser, updateuser, getuser, getuserbyid, deleteuser, statususer};
