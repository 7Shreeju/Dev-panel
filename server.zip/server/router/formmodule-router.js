const express = require("express");
const router = express.Router();
const Formmodulecontrollers = require("../controllers/formmodule-controller");

router.route("/createpages").post(Formmodulecontrollers.create_pages);
router.route("/updatepages/:id").patch(Formmodulecontrollers.update_pages);

router.route("/get/:id").get(Formmodulecontrollers.getdata);
router.route("/getall").get(Formmodulecontrollers.getall);
router.route("/delete/:id").delete(Formmodulecontrollers.deletedata);




module.exports = router;